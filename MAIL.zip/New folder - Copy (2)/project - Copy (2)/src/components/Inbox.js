import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Inbox = () => {
  const [receivedEmails, setReceivedEmails] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchReceivedEmails = async () => {
      const token = localStorage.getItem('token'); // Assuming you store the JWT token in local storage
      try {
        const response = await axios.get('http://localhost:3000/api/emails/inbox', {
          headers: {
            Authorization: `Bearer ${token}`
          }
        });
        
        setReceivedEmails(response.data);
      } catch (err) {
        setError("Error fetching received emails: " + err.message);
        // console.error('Error fetching received emails:', err);
      }
    };

    fetchReceivedEmails();
  }, []);

  return (
    <div>
      <h2>Inbox</h2>
      {error && <p>{error}</p>}
      <ul>
        {receivedEmails.map((email) => (
          <li key={email._id}>
            <strong>From:</strong> {email.from} <br />
            <strong>Subject:</strong> {email.subject} <br />
            {email.cc && (
              <>
                <strong>CC:</strong> {email.cc.join(', ')} <br />
              </>
            )}
            {email.bcc && (
              <>
                <strong>BCC:</strong> {email.bcc.join(', ')} <br />
              </>
            )}
            <strong>Received At:</strong> {new Date(email.receivedAt).toLocaleString()} <br />
            <p>{email.message}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Inbox;
