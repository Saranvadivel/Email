
import React, { useState } from 'react';
import { sendEmail } from '../services/api';
import "./Composemail.css"
function ComposeEmail() {
  const [to, setTo] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [attachment, setAttachment] = useState(null);

  const handleSendEmail = async (e) => {
    e.preventDefault();
    try {
      await sendEmail({ to, subject, message, attachment });
      alert('Email sent successfully');
    } catch (error) {
      console.error(error.response?.data || error.message);
    }
  };

  return (
    <form onSubmit={handleSendEmail}>
      <h2>Compose Email</h2>
      <input type="email" value={to} onChange={(e) => setTo(e.target.value)} required placeholder="Recipient's email" />
      <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject" />
      <textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Message"></textarea>
      <input type="file" onChange={(e) => setAttachment(e.target.files[0])} />
      <button type="submit">Send Email</button>
    </form>
  );
}

export default ComposeEmail;
