import React, { useEffect, useState } from 'react';
import { getEmails } from '../services/api';

const EmailList = () => {
  const [emails, setEmails] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchEmails = async () => {
      try {
        const response = await getEmails();
        setEmails(response.data); // Adjust based on your response structure
      } catch (err) {
        setError(err.message);
        // console.error('Error fetching emails:', err);
      }
    };

    fetchEmails();
  }, []);

  return (
    <div>
      <h2>Email List</h2>
      {error && <p>{error}</p>}
      <ul>
        {emails.map((email, index) => (
          <li key={index}>
            <strong>From:</strong> {email.from} <strong>To:</strong> {email.to} <strong>Subject:</strong> {email.subject}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EmailList;
