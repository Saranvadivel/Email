import React, { useEffect, useState } from 'react';
import axios from 'axios';

const SentEmails = () => {
  const [sentEmails, setSentEmails] = useState([]);
  const token = localStorage.getItem('token'); // Assuming you stored the JWT token in local storage

  useEffect(() => {
    const fetchSentEmails = async () => {
      try {
        const response = await axios.get('http://localhost:3000/api/emails/sent', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setSentEmails(response.data);
      } catch (error) {
        console.error("Error fetching sent emails:", error);
      }
    };

    fetchSentEmails();
  }, [token]);

  return (
    <div>
      <h1>Sent Emails</h1>
      <ul>
        {sentEmails.map((email) => (
          <li key={email._id}>
            <strong>To:</strong> {email.to}<br />
            <strong>Subject:</strong> {email.subject}<br />
            <strong>Message:</strong> {email.message}<br />
            <strong>Sent At:</strong> {new Date(email.sentAt).toLocaleString()}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SentEmails;
