const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const { connectDB } = require("./config/db");
const emailRoutes = require("./routes/emailRoutes");
const authRoutes = require("./routes/authRoutes");
const { startSmtpServer } = require("./services/smtpServer");
require("dotenv").config();
connectDB();

const app = express();
app.use(cors());
app.use(bodyParser.json());
// app.use('/uploads', express.static('uploads'));

app.use("/api/auth", authRoutes);
app.use("/api/emails", emailRoutes);

startSmtpServer();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Express server listening on http://localhost:${PORT}`);
});
